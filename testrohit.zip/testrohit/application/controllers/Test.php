<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('test_model');
		$this->load->config('extra');
	}

	public function index()
	{
		redirect(base_url('test/form_view?Action=view'));
	}
	
	function form_view(){
		// print_r($_GET);
		if($_GET['Action']=='add'){
		$record['designation']=$this->test_model->get_record('designation_master');
		$this->load->view('employee_add',$record);
		}
		elseif($_GET['Action']=='view'){
			$config=$this->config->item('pagination');
			$config['base_url'] = base_url('test/form_view?search=true');
			$config['total_rows'] =$this->test_model->get_allcount();
			// print_r($config['total_rows']);
			// $config['per_page'] = 10;
			foreach ($_GET as $key => $value) 
				{
					if($key != 'search' && $key != 'offset')
					{
						$config['base_url'] .= "&" . $key . "=" .$value;
					}
				}

			$offset = (!empty($_GET['offset'])) ? $_GET['offset'] : 0;
			$this->pagination->initialize($config);
			$record['link']=$this->pagination->create_links();
		
		$record['data']=$this->test_model->get_recordby_join($config['per_page'],$offset);
		 $this->load->view('employee_view',$record);

		}
		elseif($_GET['Action']=='edit'){
			$arr=$_GET['id'];
			// print_r($arr);
		$record['designation']=$this->test_model->get_record('designation_master');
		$record['data']=$this->test_model->get_recordby_join1($arr);
		// print_r($record);
		$this->load->view('employee_add',$record);

		}
	}

	function form_upload($id)
	{
		$ans = $this->input->post();
		$filename='';
		$img = $_FILES;
		if($id==0){
			$arr=array('em_name'=>$ans['em_name'],'em_mobile'=>$ans['em_mobile']);
			$dat=$this->test_model->get_count('employee_master',$arr);
			if($dat!=0){
				// $record=array();
				// $record['resp']=2;
				echo 2;
			}
			else{
				$insert_image = array();
				if($img['image']['error']==0)
				{
					$path =  $img['image']['name'];

					$fileName = time().'_'.$path;

					unset($config);
					$config = array();
					$config['upload_path'] =  'assetes/img/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
					$config['max_size']	= '102400';
					$config['file_name'] = $filename;

					
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('image'))
					{
						// echo "234234";
						$filename = "no_image.jpg";
						echo 3;
						// print_r($filename);
					}
					else
					{
						$imageinfo = $this->upload->data();
						$ans['em_dob']=date('Y-m-d',strtotime($ans['em_dob']));
						$ans['em_image'] = $imageinfo['file_name'];
						// print_r($imageinfo);
							// print_r($ans);
											
						$data=$this->test_model->insert_data('employee_master',$ans);
						if($data>0){
							$filename='success';
							echo 1;
						}
						else{
							$filename='no_image.jpg';
							echo 3;
						}
					}

					
				}
				else{
					$filename = "no_image.jpg";
					echo 3;	

				}
				// echo $filename;
			}
		}
		else{
				// print_r($ans);
				// print_r($img);exit;
				if(empty($img['image']['name'])){
						// $img['image']['name']=$ans['em_image'];

						$ans['em_dob']=date('Y-m-d',strtotime($ans['em_dob']));
						
							 // print_r($ans);
											
						$data=$this->test_model->insert_datawhere('employee_master',$ans,$id);
						// print_r($data);exit;
						if($data>0){
							$filename='success';
							echo 4;
						}
						else{
							$filename='no_image.jpg';
							echo 5;
						}
					
				}
				else{
					

					$path =  $img['image']['name'];

					$fileName = time().'_'.$path;
					
					unset($config);
					$config = array();
					$config['upload_path'] =  'assetes/img/';
					$config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
					$config['max_size']	= '102400';
					$config['file_name'] = $filename;

					
					$this->upload->initialize($config);
					if (!$this->upload->do_upload('image'))
					{
						// echo "234234";
						$filename = "no_image.jpg";
						echo 5;
						// print_r($filename);
					}
					else
					{
						$rec=$this->test_model->get_record('employee_master');
						
						$imageinfo = $this->upload->data();
						$ans['em_dob']=date('Y-m-d',strtotime($ans['em_dob']));
						$ans['em_image'] = $imageinfo['file_name'];
						// print_r($imageinfo);
							// print_r($ans);
						unset($ans['em_image']);				
						$data=$this->test_model->insert_datawhere('employee_master',$ans,$id);
						if($data>0){
							$filename='success';
							echo 4;
						}
						else{
							$filename='no_image.jpg';
							echo 5;
						}
					}
				}
				// echo$filename;
			}	

				
			


	}

	function deleteemployee ()
	{
		$id=$this->input->post();
		 // print_r($id);
		$arr=array('em_id'=>$id['id']);
		$data=$this->test_model->deletedata('employee_master',$arr);
		if($data>0){
			echo 1;
		}
		else{
			echo 0;
		}
	}






}