<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_model extends CI_Model {


	function get_record($table){
		return $this->db->get($table)->result_array();

	}

	function get_count($table='',$con=''){
		$this->db->where($con);
		return $this->db->count_all_results($table);
	}
	function get_where($table='',$con=''){
		$this->db->where($con);
		return $this->db->get($table)->result_array();
	}

	function insert_data($table='',$arr=''){
		
		$this->db->insert($table,$arr);
		return $this->db->insert_id();
	}
	function insert_datawhere($table='',$arr='',$con=''){
		$this->db->where('em_id',$con);
		return$this->db->update($table,$arr);
		// return $this->db->insert_id();
	}

	function get_recordby_join($par_page,$offset){

		// $str="SELECT cm.*,tbm.tbm_bill_no,tvm.tvm_voucher_no
		// 						 FROM client_master cm
		// 						 LEFT JOIN tail_bill_master tbm ON(cm.client_id = tbm.tbm_client_id)
		// 						 LEFT JOIN tail_voucher_master tvm ON(cm.client_id = tvm.tvm_client_id)
		// 						 WHERE 1 $subsql GROUP BY cm.client_id ORDER BY cm.client_accno $sort_by
		// 						 LIMIT $per_page OFFSET $offset";
		$subsql='';
		if (isset($_GET['name'])){
			$subsql.="AND em.em_name like '%".$_GET['name']."%'";
		}
		if (isset($_GET['dob'])){
			$subsql.="AND em.em_dob like '%".$_GET['dob']."%'";
		}
		if (isset($_GET['mobile'])){
			$subsql.="AND em.em_mobile like '%".$_GET['mobile']."%'";
		}
		if (isset($_GET['gender'])){
			$subsql.="AND em.em_gender like '%".$_GET['gender']."%'";
		}
		if (isset($_GET['age'])){
			$subsql.="AND em.em_age like '%".$_GET['age']."%'";
		}
		if (isset($_GET['designation'])){
			$subsql.="AND em.em_designation like '%".$_GET['designation']."%'";
		}

		$result=$this->db->query("SELECT em.*,dm.* FROM employee_master em LEFT JOIN designation_master dm ON(em.em_designation=dm.dm_id) WHERE 1 $subsql ORDER BY em.em_id DESC LIMIT $par_page OFFSET $offset")->result_array();
		return $result;
	}

	function get_recordby_join1($arr){
		$result=$this->db->query("SELECT em.*,dm.* FROM employee_master em LEFT JOIN designation_master dm ON(em.em_designation=dm.dm_id) WHERE em.em_id=$arr ")->result_array();
		return $result;
	}

	function get_allcount(){
		return $this->db->count_all('employee_master');
	}


	function deletedata($table='',$arr=''){
		return$this->db->delete($table,$arr);
	}


}
