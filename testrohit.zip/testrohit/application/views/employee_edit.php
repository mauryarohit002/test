<?php 
$this->load->view('header');

// print_r($data);

?>

<div class="col-md-4 col-md-offset-4">
	<div style="text-align:center; margin: 20px;">
		<b> <?php echo(!empty($data)?'update':'add') ?> Employee master </b>
	</div>
	<div class="alert_msg"></div>
	<form class="form-horizontal"  id="add_form"  method="post" enctype="multipart/form-data">
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="Name">Name:</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="name" name="em_name" value="<?php echo(!empty($data[0]['em_name'])?$data[0]['em_name']:''); ?>" placeholder="Enter name">
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="dob">DOB:</label>
	    <div class="col-sm-10" id="date_piker"> 
	      <input type="text" class="form-control" id="dob" name="em_dob" value="<?php echo(!empty($data[0]['em_dob'])?date('d-m-Y',strtotime($data[0]['em_dob'])):''); ?>" onChange="calulatdob(this.value)" placeholder="Enter DOB " >
	    </div>
	  </div>
	  <div class="form-group"> 
	    <label class="control-label col-sm-2" for="gender">Gender:</label>
	    <div class="col-sm-10 gender">
	      
	        <label><input type="radio" name="em_gender" id="male" value="male" <?php echo(!empty($data[0]['em_gender']))?(($data[0]['em_gender']=='male')?'checked':''):''; ?> > male</label>
	        <label><input type="radio" name="em_gender" id="female" value="female" <?php echo(!empty($data[0]['em_gender']))?(($data[0]['em_gender']=='female')?'checked':''):''; ?>> female</label>
	    	<label id="gender"></label>

	      
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="mobile">mobile:</label>
	    <div class="col-sm-10"> 
	      <input type="text" class="form-control" id="mobile" name="em_mobile" value="<?php echo(!empty($data[0]['em_mobile'])?$data[0]['em_mobile']:''); ?>" placeholder="Enter mobile no." >
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="age">Age:</label>
	    <div class="col-sm-10"> 
	      <input type="text" class="form-control" id="age" name="em_age" value="<?php echo(!empty($data[0]['em_age'])?$data[0]['em_age']:''); ?>" placeholder="Enter age" readonly="">
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="salaried">salaried:</label>
	    <div class="col-sm-10"> 
	      <select name="em_salaried" id="salaried">
	      	 <option value="0" <?php echo(!empty($data[0]['em_salaried']))?(($data[0]['em_salaried']==0)?'selected':''):''; ?> >No</option>
	      	 <option value="1" <?php echo(!empty($data[0]['em_salaried']))?(($data[0]['em_salaried']==1)?'selected':''):''; ?>>YES</option>
	      </select>
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-3" for="designation">Designation:</label>
	    <div class="col-sm-9"> 
	       <select name="em_designation" id="designation" value="" style="width:100%">
	       		<option value=>Please select</option>
	       		<?php  
	       		// print_r($designation);
	       			foreach ($designation as $value): ?>
	       			<option value="<?php echo $value['dm_id']?>" <?php echo(!empty($data[0]['em_designation']))?(($data[0]['em_designation']==$value['dm_id'])?'selected':''):''; ?> ><?php echo $value['dm_name'] ?></option>
	       			
	       			<?php
	       			endforeach;
	       		 ?>
	       </select>
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="note">Notes:</label>
	    <div class="col-sm-10"> 
	      <textarea type="text" class="form-control" id="notes" name="em_notes"  placeholder="Enter password"><?php echo(!empty($data[0]['em_notes'])?$data[0]['em_notes']:''); ?></textarea>
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="salary">salary:</label>
	    <div class="col-sm-10"> 
	      <input type="text" class="form-control" id="salary" name="em_salary" value="<?php echo(!empty($data[0]['em_salary'])?$data[0]['em_salary']:''); ?>" onchange="setdecimal(this)" placeholder="Enter salary">
	    </div>
	  </div>
	  <div class="form-group">
	    <label class="control-label col-sm-2" for="photo">photo upload:</label>
	    <div class="col-sm-10"> 
	      <input type="file" class="form-control" id="image" name="image" value="">
	      <img src="<?php echo(!empty($data[0]['em_image'])?base_url('assetes/img/'.$data[0]['em_image']):''); ?>" style="width:50px">
	    </div>
	  </div>
      <div class="form-group"> 
	    <div class="col-sm-offset-2 col-sm-4">
	      <button type="button" onclick="<?php echo(!empty($data[0]['em_id'])?'add_form('.$data[0]['em_id'].')':'add_form(0)'); ?>" class="btn btn-default"><?php echo(!empty($data)?'update':'submit') ?></button>
	    </div>
	    <div class="col-sm-offset-2 col-sm-4">
	      <a href="<?php echo base_url('test/form_view?Action=view'); ?>"><button type="button" class="btn btn-default">cancel</button></a>
	    </div>
	  </div>
	</form>
</div>

<?php 
$this->load->view('footer');

 ?>
