<?php 
$this->load->view('header');
$name=(isset($_GET['name']))?$_GET['name']:'';
$dob=(isset($_GET['dob']))?$_GET['dob']:'';
$mobile=(isset($_GET['mobile']))?$_GET['mobile']:'';
$gender=(isset($_GET['gender']))?$_GET['gender']:'';
$age=(isset($_GET['age']))?$_GET['age']:'';
$designation=(isset($_GET['designation']))?$_GET['designation']:'';

$action=(isset($_GET['Action']))?$_GET['Action']:'';
 ?>
 	<style type="text/css">
 		.form-inline .form-group{
 			margin:5px;
 			/*margin-bottom:5px;*/
 		}
 	</style>

	<div class="container">
		<div class="row">
			<form class="form-inline" action="<?php echo base_url('test/form_view'); ?>" method="get">
			    <div class="form-group">
			      	<label for="Name">Name:</label>
			      	<input type="text" class="form-control" id="name" name="name" value="<?php echo$name ?>">
			    </div>
			    <div class="form-group">
			      	<label for="dob">Dob:</label>
			      	<input type="text" class="form-control" id="dob" name="dob" value="<?php echo$dob ?>">
			    </div>
			    <div class="form-group">
			      	<label for="mobile">mobile:</label>
			      	<input type="number" class="form-control" id="mobile" name="mobile" value="<?php echo$mobile ?>">
			    </div>
			    <div class="form-group">
			      	<label for="gender">gender:</label>
			      	<input type="text" class="form-control" id="gender" name="gender" value="<?php echo$gender ?>">
			    </div>
			    <div class="form-group">
			      	<label for="age">age:</label>
			      	<input type="text" class="form-control" id="age" name="age" value="<?php echo$age ?>">
			    </div>
			    <div class="form-group">
			      	<label for="designation">designation:</label>
			      	<input type="text" class="form-control" id="designation" name="designation" value="<?php echo$designation ?>">
			    </div>
			    <input type="hidden" class="form-control" id="action" name="Action" value="<?php echo$action ?>">

			    <br>
			    <br>
			    <div class="text-center">
			    	<button type="submit" class="btn btn-default">Search</button>
			    	<a href="<?php echo base_url('test/form_view?Action=view') ?>"><button type="button" class="btn btn-default">Reload</button></a>
			    </div>
			</form>
		</div>
		<div class="row">	
		  	<h2 style="display: inline-block;">Employee Table</h2>
		  	<?php //print_r($data); ?>
		  	<!-- <p>The .table-condensed class makes a table more compact by cutting cell padding in half:</p> -->
		 	<a href="<?php echo base_url('test/form_view?Action=add') ?> " class="pull-right" style="margin:15px;">		<button type="" class="btn btn-primary">Add Employee</button>
		  	</a>
	  	</div>            
	  	<table class="table table-hover table-bordered">
	    	<thead bgcolor="#337ab7" style="color:#fff;">
	      		<tr>
			        <th>Name</th>
			        <th>DOB</th>
			        <th>Gender</th>
			        <th>Mobile</th>
			        <th>Age</th>
			        <th>Salaried</th>
			        <th>Designation</th>
			        <th>Notes</th>
			        <th>Salary</th>
			        <th>image</th>
			        <th>Edit</th>
			        <th>Delete</th>

			    </tr>
	    	</thead>
	    	<tbody>
	    	<?php if(!empty($data)):
	    		foreach ($data as $key => $value):
	    			// print_r($value);
	    		$emid=$value['em_id'];

	    	?>	
			    <tr>
			        <td><?php  echo$value['em_name']?></td>
			        <td><?php  echo date('d-m-Y',strtotime($value['em_dob']))?></td>
			        <td><?php  echo$value['em_gender']?></td>
			        <td><?php  echo$value['em_mobile']?></td>
			        <td><?php  echo$value['em_age']?></td>
			        <td><?php  echo($value['em_salaried']==1)?'Yes':'No';?></td>
			        <td><?php  echo$value['dm_name']?></td>
			        <td><?php  echo$value['em_notes']?></td>
			        <td><?php  echo$value['em_salary']?></td>
			        <td><img src="<?php  echo base_url('assetes/img/').$value['em_image'];?>" style="width:30px"></td>
			        <td><a href="<?php echo base_url('test/form_view?Action=edit&id=').$emid; ?>" >Edit</a></td>
			        <td><a href="#" onClick="delete_this('<?php echo$emid; ?>')">Delete</a></td>

			        
			    </tr>
	  		<?php 
		  		endforeach;
		  		endif;
	  	 	?>
	    	</tbody>
	  	</table>
		<div class="row">
			<div class="text-right">
				<?php echo $link; ?>
			</div>	  	
		</div>
	</div>

 	<?php 
		$this->load->view('footer');

 	?>