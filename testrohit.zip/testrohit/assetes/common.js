$(function(){
	$('#date_piker input').datepicker({format: 'dd-mm-yyyy', autoclose: true}).on('changeDate',function(ev){$('.datepicker').hide()});
})

function display_alert(type,message)
    {
    	var alert_msg = '';

        if(type == 'err')
        {
        	alert_msg += '<div class="alert" style="background-color:red;color:white;" role="alert">';
            alert_msg += '<span><strong>'+message+'</strong></span></div>';
        }
        else if(type == 'warn')
        {
            alert_msg += '<div class="alert " style="background-color:#a67473;color:white;" role="alert">';
            alert_msg += '<span ><strong>'+message+'</strong></span></div>';
        }
        else if(type == 'succ')
        {
            alert_msg += '<div class="alert alert-success" style="background-color:#49ed77;color:white;" role="alert">';
            alert_msg += '<span><strong>'+message+'</strong></span></div>';
        }

        $(".alert_msg").html(alert_msg);

        setTimeout(function(){
    		$(".alert_msg").html("");    	
        },5000);
    }

	function calulatdob(dob){
		 // var db= new Date(dob);
		    var b=dob.split('-');
		    var dtB = new Date (b[2], b[1] - 1,b[0]);
		var dby=dtB.getFullYear();
		// console.log('db= '+dtB);

		var curdate=new Date();
		var	cury=curdate.getFullYear();		
		var age=cury-dby;
		// console.log('cury= '+cury);  
		if(dob=='')age=''; 
		$('#age').val(age);
	}
	// setInterval(calulatdob,1000);

	function setdecimal(input){
			 input.value=parseFloat(input.value).toFixed(2);
	}

	function add_form(id){
		var check=0;
		if($('#name').val()==''){
			$('#name').css({'border-color':'red'});
			check=1
		}
		else{
			$('#name').css({'border-color':'#ccc'});
		}

		if($('#dob').val()==''){
			$('#dob').css({'border-color':'red'});
			check=1
		}
		else{
			$('#dob').css({'border-color':'#ccc'});
		}

		if(!(document.getElementById('male').checked || document.getElementById('female').checked)){
			$('.gender').css({'border':'1px solid red'});
			check=1;
			// console.log('rom');
			// $('#gender').html('please select gender').css({'color':'red'});
		}
		else{
			$('#male,#female').css({'border-color':'#ccc'});
			$('.gender').css({'border':'none'});

		}

		if($('#mobile').val()==''){
			$('#mobile').css({'border-color':'red'});
			check=1
		}
		else{
			$('#mobile').css({'border-color':'#ccc'});
		}
		if($('#age').val()==''){
			$('#age').css({'border-color':'red'});
			check=1
		}
		else{
			$('#age').css({'border-color':'#ccc'});
		}

		if($('#designation').val()=='' ){
			$('#designation').css({'border-color':'red'});
			check=1
		}
		else{
			$('#designation').css({'border-color':'#ccc'});
		}

		if($('#salary').val()==''){
			$('#salary').css({'border-color':'red'});
			check=1
		}
		else{
			$('#salary').css({'border-color':'#ccc'});
		}


		if(id==0){
			if($('#image').val()==''){
				$('#image').css({'border-color':'red'});
				check=1
			}
			else{
				$('#image').css({'border-color':'#ccc'});
			}
		}
		
		if(check==1){
			
			var msg = 'Oh snap ! You forgot to enter some information';
            display_alert('err',msg);

            $("body, html").animate({
                'scrollTop':0
            },1000);

		}

		else{
		 	var form_obj  = document.getElementById("add_form");                
            var form_data_obj   = new FormData(form_obj);
			var path=base_path+'test/form_upload/'+id;
			// var data=$('#add_form').serialize();
			$.ajax({
				type:'post',
				url:path,
				data:form_data_obj,
				enctype:"multipart/form-data",
				// datatype:'json',
				processData: false,
    			contentType: false,
    			success:function(data){
    				 // alert(data);

    				 if(id==0){
    				 	if(data==1){
    				 		var msg = 'successfully added.';
	            			display_alert('succ',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
	            			$('#add_form')[0].reset();
    				 	}
    				 	else if(data==2){
    				 		var msg = 'Client Name And Mobile No already Exists.';
	            			display_alert('err',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
	            			// $('#add_form')[0].reset();	
    				 	}
    				 	else if(data==3){
    				 		var msg = 'no image found!';
	            			display_alert('err',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
	            			// $('#add_form')[0].reset();
    				 	}
    				 	else{
    				 		var msg = 'Database Error ! Please try again later';
	            			display_alert('warn',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
    				 	}
    				}

    				else{

    				 	if(data==4){
    				 		var msg = 'successfully update.';
	            			display_alert('succ',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
	            			// $('#add_form')[0].reset();
    				 	}
    				 	else if(data==5){
    				 		var msg = 'no image found!';
	            			display_alert('err',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
	            			// $('#add_form')[0].reset();
    				 	}
    				 	else{
    				 		var msg = 'Database Error ! Please try again later';
	            			display_alert('warn',msg);
	            			$("body, html").animate({
				                'scrollTop':0
				            },2000);
    				 	}
    				 }	

    				// if(data=='success'){
    				// 	var msg = 'successfully added';
        //     			display_alert('succ',msg);
        //     			$("body, html").animate({
			     //            'scrollTop':0
			     //        },1000);
        //     			$('#add_form')[0].reset();
    				// }
    				// else{
    				// 	var msg = 'something went wrong!';
        //     			display_alert('err',msg);
    				// }

    			},
    			error:function(data){
    				console.log(data);
    			}
			})


		 }
		

	}

	function delete_this(id){
		var ans=confirm('Are you sure ? You want to delete this employee record.');
		// console.log(id);
		if(ans==true){
		 var path=base_path+'test/deleteemployee';

			$.ajax({
				type:'post',
				url:path,
				// datatype:'json',
				data:{id:id},
				success:function(data){
					if (data==1) {
						location.reload();
					}
					else{
					console.log(data);

					}
				},
				error:function(data){
					console.log(data);
				}
			});

		}
		else{
			return false;
		}
	}


